let kioskUrl = "https://your-kiosk-url.com";
let marketingUrl = "https://your-marketing-url.com";
let idleTimeout = 60;
let enableRedirect = true;
let isIdle = false;
let lastActiveTabId = null; // Track last active tab

async function loadSettings() {
    console.log("🔄 Loading settings from storage...");

    // Step 1️⃣: Read from `chrome.storage.managed` (Admin Console JSON)
    let managedSettings = await new Promise((resolve) =>
        chrome.storage.managed.get(["kioskUrl", "marketingUrl", "idleTimeout", "enableRedirect"], resolve)
    );
    console.log("📢 Managed Storage Data:", managedSettings);

    // Step 2️⃣: Read from `chrome.storage.sync` (User settings)
    let userSettings = await new Promise((resolve) =>
        chrome.storage.sync.get(["kioskUrl", "marketingUrl", "idleTimeout", "enableRedirect"], resolve)
    );
    console.log("📢 User Storage Data:", userSettings);

    // ✅ Apply settings with priority: Admin Console > User Settings > Defaults
    kioskUrl = managedSettings.kioskUrl ?? userSettings.kioskUrl ?? kioskUrl;
    marketingUrl = managedSettings.marketingUrl ?? userSettings.marketingUrl ?? marketingUrl;
    idleTimeout = managedSettings.idleTimeout ?? userSettings.idleTimeout ?? idleTimeout;
    enableRedirect = managedSettings.enableRedirect ?? userSettings.enableRedirect ?? enableRedirect;

    console.log("✅ Final Settings Applied:");
    console.log(" - Kiosk URL:", kioskUrl);
    console.log(" - Marketing URL:", marketingUrl);
    console.log(" - Idle Timeout:", idleTimeout, "seconds");
    console.log(" - Idle Redirect Enabled:", enableRedirect);

    // ✅ Apply new idle timeout
    chrome.idle.setDetectionInterval(idleTimeout);
}


// ✅ Listen for storage changes & update settings in real-time
chrome.storage.onChanged.addListener((changes, namespace) => {
    console.log("🔄 Storage settings updated:", changes);

    if (namespace === "managed") {
        console.log("📢 Admin Console settings updated. Reloading...");
        loadSettings(); // ✅ Force reload of settings from Admin Console
    }
});




// ✅ Track last active tab (ensures correct redirection)
chrome.tabs.onActivated.addListener((activeInfo) => {
    lastActiveTabId = activeInfo.tabId;
    console.log("🖥 Last active tab updated:", lastActiveTabId);
});

// ✅ Register Idle State Listener (Ensures it always runs)
chrome.idle.onStateChanged.addListener((newState) => {
    console.log("🔥 Idle state CHANGED:", newState);

    if ((newState === "idle" || newState === "locked") && !isIdle) {
        console.log("🚀 System went idle. Redirecting last active tab to marketing...");
        goToMarketing();
    } else if (newState === "active" && isIdle) {
        console.log("💡 System became active. Redirecting last active tab back to kiosk...");
        returnToKiosk();
    }
});

// ✅ Periodically reapply idle detection (Prevents event loss)
setInterval(() => {
    console.log("🔄 Reapplying idle detection interval...");
    chrome.idle.setDetectionInterval(idleTimeout);
}, 600000); // Every 10 minutes

// ✅ Check Idle State Every 10 Seconds for Debugging
setInterval(() => {
    chrome.idle.queryState(idleTimeout, (state) => {
        console.log("🕒 Periodic Idle State Check:", state);
    });
}, 10000);

// ✅ Force Initialize Idle Detection (Ensures it's always active)
async function initialize() {
    await loadSettings();
    console.log("🚀 Initializing idle detection with timeout:", idleTimeout, "seconds");
    chrome.idle.setDetectionInterval(idleTimeout);
}

// ✅ Ensure the Extension Initializes on Startup or Wake-Up
chrome.runtime.onStartup.addListener(() => {
    console.log("🔄 Kiosk extension restarted. Running initialization...");
    initialize();
});

// ✅ Keep Service Worker Alive (Prevents Unexpected Unloading)
setInterval(() => {
    console.log("⏳ Keeping background service worker alive...");
}, 60000);

// ✅ Redirect to Marketing Page When Idle
function goToMarketing() {
    if (!enableRedirect || lastActiveTabId === null) return;

    console.log("Redirecting last active tab:", lastActiveTabId, "to marketing URL:", marketingUrl);
    isIdle = true;
    chrome.tabs.update(lastActiveTabId, { url: marketingUrl });
}

// ✅ Redirect Back to Kiosk Page When Active
function returnToKiosk() {
    if (!enableRedirect || lastActiveTabId === null) return;

    console.log("Redirecting last active tab:", lastActiveTabId, "to kiosk URL:", kioskUrl);
    isIdle = false;
    chrome.tabs.update(lastActiveTabId, { url: kioskUrl });
}

// ✅ Detect User Activity and Return to Kiosk
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log("📩 Received message:", message);

    if (message.type === "user_active") {
        console.log("💡 User activity detected. Redirecting to kiosk...");

        chrome.storage.sync.get(["kioskUrl"], (data) => {
            let latestKioskUrl = data.kioskUrl || "https://your-kiosk-url.com";

            chrome.tabs.query({}, (tabs) => {
                let lastTab = tabs.find(tab => tab.active) || tabs[0];

                if (lastTab && lastTab.url !== latestKioskUrl) {
                    console.log("🏠 Navigating back to kiosk URL:", latestKioskUrl);
                    chrome.tabs.update(lastTab.id, { url: latestKioskUrl });
                }
            });
        });

        sendResponse({ status: "success" });
        return true;
    }
});

// ✅ Listen for Storage Changes and Apply New Settings in Real-Time
chrome.storage.onChanged.addListener((changes, namespace) => {
    console.log("🔄 Storage settings updated:", changes);

    if (namespace === "sync") {
        if (changes.kioskUrl) {
            kioskUrl = changes.kioskUrl.newValue;
            console.log("✅ Updated kiosk URL to:", kioskUrl);
        }
        if (changes.marketingUrl) {
            marketingUrl = changes.marketingUrl.newValue;
            console.log("✅ Updated marketing URL to:", marketingUrl);
        }
        if (changes.idleTimeout) {
            idleTimeout = changes.idleTimeout.newValue;
            console.log("✅ Updated idle timeout to:", idleTimeout, "seconds");

            // ✅ Reapply the new idle timeout immediately
            chrome.idle.setDetectionInterval(idleTimeout);
        }
        if (changes.enableRedirect) {
            enableRedirect = changes.enableRedirect.newValue !== false;
            console.log("✅ Updated enableRedirect to:", enableRedirect);
        }
    }
});


// ✅ Run Initialization Immediately When Extension Loads
initialize();
